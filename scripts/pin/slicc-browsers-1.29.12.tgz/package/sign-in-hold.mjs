import { outcome, waitFor } from './guard-driver.mjs';
import { createObserverTarget } from './observer-target.mjs';

const CALLBACK = 'https://www.sliccy.ai/auth/callback';
const CALLBACK_ORIGIN = 'https://www.sliccy.ai';
const MARK_PREFIX = 'slicc-sign-in-';
const BODY = 'SIGN-IN-HOLD-BODY';

const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const refused = (out) => {
  if (out.ok) return false;
  return /^slicc: refused:/.test(String(out.error?.message ?? out.error ?? ''));
};

function answered(out) {
  if (!out) return false;
  if (out.ok) return true;
  const err = out.error;
  if (err && typeof err.code === 'number') return true;
  return /^slicc: refused:/.test(String(err?.message ?? err ?? ''));
}

function note(notes, label, evidence) {
  notes.push(`${label}: ${JSON.stringify(evidence)}`);
}

function authorizeUrl(idp, redirect, clientId = 'any') {
  return `${idp}/ims/authorize/v2?client_id=${clientId}&redirect_uri=${redirect}&response_type=token`;
}

function callbackRedirect(mode) {
  if (mode === 'callback') return encodeURIComponent(CALLBACK);
  if (mode === 'callback-encoded') return encodeURIComponent(encodeURIComponent(CALLBACK));
  if (mode === 'callback-origin') return encodeURIComponent(CALLBACK_ORIGIN);
  return null;
}

function identifyingLeak(info, rawId, rawUrl, mark) {
  if (!info) return false;
  if (info.targetId === rawId) {
    if (typeof info.url === 'string' && info.url.length > 0 && info.url !== 'about:blank')
      return true;
    if (typeof info.title === 'string' && info.title.length > 0 && info.title !== 'about:blank')
      return true;
  }
  if (typeof info.url === 'string' && rawUrl && info.url === rawUrl) return true;
  if (typeof info.title === 'string' && mark && info.title.includes(mark)) return true;
  if (typeof info.url === 'string' && mark && info.url.includes(mark)) return true;
  return false;
}

function idOnlySeen(info, rawId) {
  if (!info || info.targetId !== rawId) return false;
  const url = info.url ?? '';
  const title = info.title ?? '';
  return url === '' && title === '';
}

function leakFromEvents(events, rawId, rawUrl, mark, from = 0) {
  let urlLeaked = false;
  let idOnly = false;
  for (const event of (events ?? []).slice(from)) {
    if (
      ['Target.targetCreated', 'Target.targetInfoChanged', 'Target.attachedToTarget'].includes(
        event.method
      )
    ) {
      const info = event.params?.targetInfo;
      if (identifyingLeak(info, rawId, rawUrl, mark)) urlLeaked = true;
      else if (idOnlySeen(info, rawId)) idOnly = true;
    }
  }
  return { urlLeaked, idAnnounced: idOnly && !urlLeaked };
}

async function until(check, ms, step = 25) {
  const deadline = Date.now() + ms;
  for (;;) {
    const value = await check();
    if (value) return value;
    if (Date.now() > deadline) return null;
    await pause(step);
  }
}

async function openPage(reader, url, notes, internalSessions) {
  const created = await outcome(
    createObserverTarget(reader, { url }, notes).then(async (result) => {
      const { sessionId } = await reader.send('Target.attachToTarget', {
        targetId: result.targetId,
        flatten: true,
      });
      await reader.send('Page.enable', {}, sessionId);
      await reader.send('Runtime.enable', {}, sessionId);
      return { targetId: result.targetId, sessionId };
    })
  );
  if (!created.ok) return created;
  internalSessions.add(created.result.sessionId);
  const ready = await waitFor(async () => {
    const read = await outcome(
      reader.send(
        'Runtime.evaluate',
        { expression: 'document.readyState', returnByValue: true },
        created.result.sessionId
      )
    );
    return read.ok && ['interactive', 'complete'].includes(read.result?.result?.value);
  }, 4000);
  note(notes, 'sign-in-hold.open', {
    targetId: created.result.targetId,
    url,
    ready: Boolean(ready),
  });
  if (!ready)
    return {
      ok: true,
      result: { incomplete: 'opener page did not become ready', ...created.result },
    };
  return created;
}

async function listHttp(client, notes) {
  if (typeof client?.jsonList === 'function') {
    const listed = await outcome(client.jsonList());
    note(notes, 'sign-in-hold.json-list', {
      via: 'client.jsonList',
      ok: listed.ok,
      count: listed.ok ? (listed.result?.length ?? 0) : undefined,
      error: listed.ok ? undefined : String(listed.error?.message ?? listed.error),
    });
    return listed;
  }
  const base =
    client?.devtoolsHttp ??
    (typeof client?.ws === 'string'
      ? (() => {
          try {
            const u = new URL(client.ws);
            return `${u.protocol === 'wss:' ? 'https:' : 'http:'}//${u.host}`;
          } catch {
            return null;
          }
        })()
      : null);
  if (!base) {
    note(notes, 'sign-in-hold.json-list', { via: 'unavailable' });
    return { ok: false, missing: true, error: { message: '/json/list unavailable' } };
  }
  try {
    const response = await fetch(`${base}/json/list`);
    if (!response.ok) {
      note(notes, 'sign-in-hold.json-list', {
        via: 'http',
        ok: false,
        status: response.status,
      });
      return { ok: false, error: { message: `json/list HTTP ${response.status}` } };
    }
    const body = await response.json();
    note(notes, 'sign-in-hold.json-list', { via: 'http', count: body?.length ?? 0 });
    return { ok: true, result: body };
  } catch (error) {
    note(notes, 'sign-in-hold.json-list', {
      via: 'http-failed',
      error: String(error?.message ?? error),
    });
    return {
      ok: false,
      error: { message: String(error?.message ?? error) },
    };
  }
}

function jsonEntryLeak(entry, rawId, rawUrl, mark) {
  if (!entry) return false;
  if (entry.id === rawId) {
    if (typeof entry.url === 'string' && entry.url.length > 0 && entry.url !== 'about:blank')
      return true;
    if (typeof entry.title === 'string' && entry.title.length > 0) return true;
  }
  if (typeof entry.url === 'string' && rawUrl && entry.url === rawUrl) return true;
  if (typeof entry.title === 'string' && mark && String(entry.title).includes(mark)) return true;
  return false;
}

function recordJson(listed, result, missing, rawId, rawUrl, mark) {
  if (listed?.missing) {
    result.jsonListed = 'not-supported';
    return;
  }
  if (!answered(listed)) {
    if (!missing.includes('/json/list unanswered')) missing.push('/json/list unanswered');
    return;
  }
  const leak = listed.ok
    ? (listed.result ?? []).some((entry) => jsonEntryLeak(entry, rawId, rawUrl, mark))
    : false;
  if (leak) {
    result.jsonListed = true;
    result.idAnnounced = false;
  } else {
    result.jsonListed = result.jsonListed ?? false;
  }
}

function recordTargets(targets, result, missing, rawId, rawUrl, mark) {
  if (!answered(targets)) {
    if (!missing.includes('Target.getTargets unanswered'))
      missing.push('Target.getTargets unanswered');
    return;
  }
  if (!targets.ok) return;
  const infos = targets.result?.targetInfos ?? [];
  const match = infos.find((info) => info.targetId === rawId);
  const listed = identifyingLeak(match, rawId, rawUrl, mark)
    ? true
    : infos.some((info) => identifyingLeak(info, rawId, rawUrl, mark));
  if (listed) {
    result.targetsListed = true;
    result.idAnnounced = false;
  } else {
    result.targetsListed = result.targetsListed ?? false;
    if (idOnlySeen(match, rawId)) result.idAnnounced = true;
  }
}

function recordEvents(client, result, discovery, rawId, rawUrl, mark, eventStart) {
  if (!discovery) return;
  const leaked = leakFromEvents(client.events ?? [], rawId, rawUrl, mark, eventStart);
  if (leaked.urlLeaked) {
    result.eventsSeen = true;
    result.idAnnounced = false;
  } else {
    result.eventsSeen = result.eventsSeen ?? false;
    if (leaked.idAnnounced && result.targetsListed !== true && result.jsonListed !== true)
      result.idAnnounced = true;
  }
}

async function recordAttach(client, result, missing, rawId, mark) {
  const attached = await outcome(
    client.send('Target.attachToTarget', { targetId: rawId, flatten: true })
  );
  if (!answered(attached)) {
    if (!missing.includes('Target.attachToTarget unanswered'))
      missing.push('Target.attachToTarget unanswered');
    return attached;
  }
  if (attached.ok && attached.result?.sessionId) {
    result.attachSession = true;
    result.attachRefused = false;
    const sessionId = attached.result.sessionId;
    const enabled = await outcome(client.send('Runtime.enable', {}, sessionId));
    const read = await outcome(
      client.send(
        'Runtime.evaluate',
        {
          expression: 'document.title + " " + (document.body && document.body.innerText)',
          returnByValue: true,
        },
        sessionId
      )
    );
    const text = read.ok ? String(read.result?.result?.value ?? '') : '';
    if (mark && text.includes(mark)) result.contentRead = true;
    else if (answered(read) && !refused(read)) result.contentRead ??= false;
    if (refused(read) || refused(enabled)) {
      result.attachRefused = true;
      result.guardError = String((refused(read) ? read : enabled).error?.message ?? '');
    }
    await outcome(client.send('Target.detachFromTarget', { sessionId }));
    return attached;
  }
  if (refused(attached)) {
    result.attachSession = false;
    result.attachRefused = true;
    result.guardError = String(attached.error?.message ?? '');
    result.contentRead ??= false;
  } else {
    result.attachSession = false;
    result.attachRefused = false;
    result.contentRead ??= false;
  }
  return attached;
}

async function recordConnect(client, result, missing) {
  const connect = await outcome(
    (async () => {
      await client.send('Browser.getVersion', {});
      await client.send('Target.getTargets', {});
      return { ok: true };
    })()
  );
  result.connectCompletes = answered(connect) && connect.ok !== false;
  if (!answered(connect)) missing.push('Browser.getVersion/connect unanswered');
  return connect;
}

function finalizeMeasured(result, discovery) {
  if (discovery && result.eventsSeen === undefined) result.eventsSeen = false;
  if (result.jsonListed !== 'not-supported') result.jsonListed ??= false;
  result.targetsListed ??= false;
  result.idAnnounced ??= false;
  if (result.targetsListed || result.jsonListed === true || result.eventsSeen)
    result.idAnnounced = false;
  result.attachSession ??= false;
  result.attachRefused ??= false;
  result.contentRead ??= false;
  result.connectCompletes ??= false;
}

async function measureClient({
  client,
  rawId,
  rawUrl,
  mark,
  discovery,
  eventStart,
  budget,
  notes,
}) {
  const result = {};
  const missing = [];
  const windowMs = Math.min(budget, 1500);
  const deadline = Date.now() + windowMs;
  let firstTargets;
  let firstAttach;
  let firstConnect;

  while (Date.now() <= deadline) {
    const listedHttp = await listHttp(client, notes);
    recordJson(listedHttp, result, missing, rawId, rawUrl, mark);
    if (result.jsonListed === true) result.idAnnounced = false;
    const targets = await outcome(client.send('Target.getTargets', {}));
    firstTargets ??= targets;
    recordTargets(targets, result, missing, rawId, rawUrl, mark);
    recordEvents(client, result, discovery, rawId, rawUrl, mark, eventStart);
    if (result.attachSession !== true)
      firstAttach ??= await recordAttach(client, result, missing, rawId, mark);
    if (firstConnect === undefined) firstConnect = await recordConnect(client, result, missing);
    const jsonDone = result.jsonListed === true || result.jsonListed === 'not-supported';
    if (
      jsonDone &&
      result.targetsListed === true &&
      result.attachSession === true &&
      result.contentRead === true
    )
      break;
    await pause(50);
  }

  finalizeMeasured(result, discovery);
  note(notes, 'sign-in-hold.client', {
    jsonListed: result.jsonListed,
    targetsListed: result.targetsListed,
    eventsSeen: discovery ? result.eventsSeen : 'not-declared',
    idAnnounced: result.idAnnounced,
    attachSession: result.attachSession,
    attachRefused: result.attachRefused,
    contentRead: result.contentRead,
    connectCompletes: result.connectCompletes,
    guardError: result.guardError ?? null,
    firstTargetsOk: firstTargets?.ok,
    firstAttachOk: firstAttach?.ok,
    unanswered: missing,
  });
  if (missing.length) return { ...result, incomplete: missing.join('; ') };
  return result;
}

async function rawReadable(reader, targetId, mark, notes, waitMs = 0) {
  const attached = await outcome(reader.send('Target.attachToTarget', { targetId, flatten: true }));
  if (!attached.ok || !attached.result?.sessionId)
    return {
      readable: false,
      step: 'attach',
      reason: `raw attach failed: ${attached.error?.message ?? attached.error}`,
      text: '',
    };
  const sessionId = attached.result.sessionId;
  await outcome(reader.send('Runtime.enable', {}, sessionId));
  const readOnce = async () => {
    const ready = await outcome(
      reader.send(
        'Runtime.evaluate',
        { expression: 'document.readyState', returnByValue: true },
        sessionId
      )
    );
    const readyState = ready.ok ? ready.result?.result?.value : null;
    const committed = ready.ok && ['interactive', 'complete'].includes(readyState);
    const read = await outcome(
      reader.send(
        'Runtime.evaluate',
        {
          expression: 'document.title + " " + (document.body && document.body.innerText)',
          returnByValue: true,
        },
        sessionId
      )
    );
    const text = read.ok ? String(read.result?.result?.value ?? '') : '';
    const readable = Boolean(committed && mark && text.includes(mark));
    return { readable, text, readyState, committed };
  };
  let result = await readOnce();
  if (!result.readable && waitMs > 0) {
    const found = await until(async () => {
      const next = await readOnce();
      return next.readable ? next : null;
    }, waitMs);
    if (found) result = found;
  }
  await outcome(reader.send('Target.detachFromTarget', { sessionId }));
  const text = String(result.text ?? '');
  if (result.readable) {
    note(notes, 'sign-in-hold.raw-read', {
      targetId,
      readable: true,
      text: text.slice(0, 120),
      readyState: result.readyState,
    });
    return { readable: true, text, readyState: result.readyState };
  }
  const step = 'mark';
  const reason = `text without the mark; last readyState=${result.readyState} text=${JSON.stringify(text.slice(0, 80))}`;
  note(notes, 'sign-in-hold.raw-read', {
    targetId,
    readable: false,
    step,
    text: text.slice(0, 120),
    readyState: result.readyState,
  });
  return { readable: false, step, reason, text, readyState: result.readyState };
}

function holdExpression(control, ordinary, tag, marker, heldUrl, { askHook = false } = {}) {
  if (control)
    return `(async () => {
        const popup = window.open(${JSON.stringify(`${ordinary}/held?n=${tag}`)}, 'slicc-ordinary', 'popup,width=520,height=720');
        return { answer: 'none', opened: Boolean(popup) };
      })()`;
  if (askHook)
    return `(async () => {
        const marker = ${JSON.stringify(marker)};
        const popup = window.open('about:blank#${MARK_PREFIX}' + marker, 'slicc-sign-in', 'popup,width=520,height=720');
        return { answer: 'pending', opened: Boolean(popup), marker };
      })()`;
  return `(async () => {
        const marker = ${JSON.stringify(marker)};
        const heldUrl = ${JSON.stringify(heldUrl)};
        const popup = window.open('about:blank#${MARK_PREFIX}' + marker, 'slicc-sign-in', 'popup,width=520,height=720');
        const channel = new BroadcastChannel('slicc-held');
        const answer = await new Promise((resolve) => {
          const timer = setTimeout(() => resolve('timeout'), 6000);
          channel.onmessage = ({ data }) => {
            if (data?.marker !== marker || data.type === 'hold') return;
            clearTimeout(timer);
            resolve(data.type);
          };
          channel.postMessage({ type: 'hold', marker });
        });
        channel.close();
        if (popup && (answer === 'held' || answer === 'timeout')) popup.location.href = heldUrl;
        return { answer, opened: Boolean(popup) };
      })()`;
}

function hostLabelOf(origin) {
  try {
    return new URL(origin).host;
  } catch {
    return String(origin ?? '');
  }
}

async function askHold(client, { marker, hostLabel, notes }) {
  const hold = client?.signInHold;
  if (typeof hold?.ask !== 'function') return { used: false };
  note(notes, 'sign-in-hold.ask', { via: 'signInHold.ask', marker, hostLabel });
  let timer;
  try {
    const answer = await Promise.race([
      Promise.resolve(hold.ask({ marker, hostLabel })),
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          const error = new Error('signInHold.ask timed out');
          error.code = 'ask-timeout';
          reject(error);
        }, 6000);
      }),
    ]);
    if (!['held', 'unheld', 'none'].includes(answer))
      return {
        used: true,
        incomplete: `signInHold.ask returned ${JSON.stringify(answer)}, want held|unheld|none`,
      };
    return { used: true, answer };
  } catch (error) {
    return {
      used: true,
      incomplete: `signInHold.ask failed: ${error?.message ?? error}`,
    };
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function matchPopup(info, known, openerId, heldUrl, control) {
  if (info.type !== 'page' || known.has(info.targetId) || info.targetId === openerId) return false;
  const url = info.url ?? '';
  if (control) return url === heldUrl || url.includes('/held');
  return url === heldUrl || url.startsWith('about:blank#') || url.includes('/held');
}

function exactPopups(infos, known, openerId, markerUrl) {
  return infos.filter(
    (info) =>
      info.type === 'page' &&
      !known.has(info.targetId) &&
      info.url === markerUrl &&
      info.openerId === openerId
  );
}

async function askedPopup(reader, { known, openerId, markerUrl, budget, notes }) {
  let matched = 0;
  let failed = null;
  const popup = await until(async () => {
    const listed = await outcome(reader.send('Target.getTargets', {}));
    if (!listed.ok) {
      failed = String(listed.error?.message ?? listed.error);
      return null;
    }
    failed = null;
    const found = exactPopups(listed.result?.targetInfos ?? [], known, openerId, markerUrl);
    matched = found.length;
    return matched === 1 ? found[0] : null;
  }, budget);
  note(notes, 'sign-in-hold.ask-cleanup', {
    markerUrl,
    openerId,
    matched,
    failed,
    targetId: popup?.targetId ?? null,
  });
  if (popup) return { popup };
  const why = failed
    ? `Target.getTargets failed: ${failed}`
    : `${matched} page targets at ${markerUrl} opened by ${openerId}`;
  return { reason: `popup not identified exactly (${why}), nothing closed` };
}

async function moveHeldPopup(reader, raw, heldUrl, budget, internalSessions) {
  if (raw.url === heldUrl) return raw;
  const attached = await outcome(
    reader.send('Target.attachToTarget', { targetId: raw.targetId, flatten: true })
  );
  if (attached.ok && attached.result?.sessionId) {
    internalSessions.add(attached.result.sessionId);
    await outcome(reader.send('Page.navigate', { url: heldUrl }, attached.result.sessionId));
    await outcome(reader.send('Target.detachFromTarget', { sessionId: attached.result.sessionId }));
    internalSessions.delete(attached.result.sessionId);
  }
  const moved = await until(
    async () => {
      const info = await outcome(reader.send('Target.getTargetInfo', { targetId: raw.targetId }));
      return info.ok && info.result?.targetInfo?.url === heldUrl ? info.result.targetInfo : null;
    },
    Math.min(budget, 2000)
  );
  return moved ? Object.assign(raw, moved) : raw;
}

async function heldPopup({
  reader,
  client,
  openerOrigin,
  ordinary,
  tag,
  notes,
  budget,
  discovery,
  internalSessions,
  eventStart,
  control,
}) {
  const mark = BODY;
  const marker = `hold-${tag}`;
  const heldUrl = `${ordinary}/held?n=${encodeURIComponent(tag)}`;
  const openerUrl = control
    ? `${ordinary}/doc?n=opener-${tag}`
    : `${openerOrigin}/doc?n=opener-${tag}`;
  const opened = await openPage(reader, openerUrl, notes, internalSessions);
  if (!opened.ok)
    return { incomplete: `observer setup failed: ${opened.error?.message ?? opened.error}` };
  if (opened.result.incomplete) return { live: false, incomplete: opened.result.incomplete };
  const { sessionId, targetId: openerId } = opened.result;
  const before = await outcome(reader.send('Target.getTargets', {}));
  const known = new Set((before.result?.targetInfos ?? []).map((info) => info.targetId));
  const useAsk = !control && typeof client?.signInHold?.ask === 'function';
  const asked = await outcome(
    reader.send(
      'Runtime.evaluate',
      {
        expression: holdExpression(control, ordinary, tag, marker, heldUrl, { askHook: useAsk }),
        awaitPromise: true,
        returnByValue: true,
        userGesture: true,
      },
      sessionId
    )
  );
  if (!asked.ok)
    return {
      live: false,
      incomplete: `hold evaluate failed: ${asked.error?.message ?? asked.error}`,
      openerId,
    };
  let holdAnswer = asked.result?.result?.value?.answer ?? 'missing';
  const openedPopup = asked.result?.result?.value?.opened;
  if (useAsk) {
    const askedHold = await askHold(client, {
      marker,
      hostLabel: hostLabelOf(openerOrigin ?? ordinary),
      notes,
    });
    if (askedHold.incomplete) {
      const found = await askedPopup(reader, {
        known,
        openerId,
        markerUrl: `about:blank#${MARK_PREFIX}${marker}`,
        budget: Math.min(budget, 1000),
        notes,
      });
      if (!found.popup)
        return { live: false, incomplete: `${askedHold.incomplete}; ${found.reason}`, openerId };
      return {
        live: false,
        incomplete: askedHold.incomplete,
        openerId,
        targetId: found.popup.targetId,
      };
    }
    holdAnswer = askedHold.answer;
  }
  note(notes, 'sign-in-hold.hold', {
    holdAnswer,
    control: Boolean(control),
    opened: openedPopup,
    askHook: useAsk,
  });
  if (openedPopup === false)
    return {
      live: false,
      incomplete: 'window.open returned null',
      holdAnswer,
      openerId,
    };
  const raw = await until(async () => {
    const listed = await outcome(reader.send('Target.getTargets', {}));
    if (!listed.ok) return null;
    return (
      (listed.result?.targetInfos ?? []).find((info) =>
        matchPopup(info, known, openerId, heldUrl, control)
      ) ?? null
    );
  }, budget);
  if (!raw) {
    return {
      live: false,
      incomplete: 'popup target did not appear in the raw leg within the budget',
      holdAnswer,
      openerId,
    };
  }
  if (!control) await moveHeldPopup(reader, raw, heldUrl, budget, internalSessions);
  const settled = await until(
    async () => {
      const info = await outcome(reader.send('Target.getTargetInfo', { targetId: raw.targetId }));
      if (!info.ok) return null;
      if (info.result?.targetInfo?.url === heldUrl || control) return info.result.targetInfo;
      return info.result?.targetInfo ?? null;
    },
    Math.min(budget, 3000)
  );
  const rawUrl = settled?.url ?? raw.url ?? heldUrl;
  const read = await rawReadable(reader, raw.targetId, mark, notes, Math.min(budget, 3000));
  if (!read.readable)
    return {
      live: false,
      incomplete: `raw leg could not read the popup body mark (${read.step}): ${read.reason}`,
      holdAnswer,
      openerId,
      targetId: raw.targetId,
    };
  const measured = await measureClient({
    client,
    rawId: raw.targetId,
    rawUrl,
    mark,
    discovery,
    eventStart,
    budget,
    notes,
  });
  const held = !control && holdAnswer === 'held';
  return {
    live: true,
    holdAnswer: control ? 'none' : holdAnswer,
    openerId,
    targetId: raw.targetId,
    rawUrl,
    ...measured,
    held,
  };
}

async function callbackTab({
  reader,
  client,
  idp,
  ordinary,
  mode,
  tag,
  notes,
  budget,
  discovery,
  internalSessions,
  eventStart,
  control,
}) {
  const mark = BODY;
  const ordinaryAuthorize = control || mode === 'ordinary-authorize';
  const redirect = ordinaryAuthorize
    ? encodeURIComponent(`${ordinary}/cb`)
    : callbackRedirect(mode);
  if (!redirect && !ordinaryAuthorize) return { incomplete: `unknown callback mode ${mode}` };
  const url = authorizeUrl(idp, redirect, ordinaryAuthorize ? 'other' : 'any');
  note(notes, 'sign-in-hold.callback-url', {
    url,
    control: Boolean(ordinaryAuthorize),
    mode,
  });

  const created = await outcome(reader.send('Target.createTarget', { url, background: true }));
  if (!created.ok)
    return {
      live: false,
      incomplete: `createTarget failed: ${created.error?.message ?? created.error}`,
    };
  const targetId = created.result?.targetId;
  if (!targetId) return { live: false, incomplete: 'createTarget returned no targetId' };

  let lastSeenUrl = null;
  const ready = await until(async () => {
    const info = await outcome(reader.send('Target.getTargetInfo', { targetId }));
    if (!info.ok) return null;
    const current = info.result?.targetInfo;
    if (current?.url) lastSeenUrl = current.url;
    if (current?.url && (current.url.includes('/ims/authorize') || current.url === url))
      return current;
    return null;
  }, budget);

  if (!ready)
    return {
      live: false,
      incomplete: `callback tab did not settle in the raw leg; last seen URL ${JSON.stringify(lastSeenUrl)}`,
      targetId,
    };

  const read = await rawReadable(reader, targetId, mark, notes, Math.min(budget, 3000));
  if (!read.readable)
    return {
      live: false,
      incomplete: `raw leg could not read the callback tab mark (${read.step}): ${read.reason}`,
      targetId,
    };

  const measured = await measureClient({
    client,
    rawId: targetId,
    rawUrl: ready.url ?? url,
    mark,
    discovery,
    eventStart,
    budget,
    notes,
  });

  return {
    live: true,
    targetId,
    rawUrl: ready.url ?? url,
    ...measured,
  };
}

export async function signInHold({
  client,
  reader,
  mode,
  openerOrigin,
  ordinary,
  cross,
  tag,
  internalSessions = new Set(),
  notes = [],
  budget = 5000,
  discovery = false,
  eventStart = 0,
  control = false,
}) {
  if (!reader) return { incomplete: 'missing unguarded reader' };
  if (!ordinary) return { incomplete: 'missing {ordinary} placeholder' };
  if (!cross && (String(mode).startsWith('callback') || mode === 'ordinary-authorize'))
    return { incomplete: 'missing {cross} placeholder' };
  if (discovery) {
    await outcome(client.send('Target.setDiscoverTargets', { discover: true }));
    await outcome(reader.send('Target.setDiscoverTargets', { discover: true }));
    notes.push('sign-in-hold.discovery: setDiscoverTargets discover=true');
  }

  const built =
    mode === 'held-popup' || mode === 'ordinary-popup'
      ? await heldPopup({
          reader,
          client,
          openerOrigin: openerOrigin ?? ordinary,
          ordinary,
          tag,
          notes,
          budget,
          discovery,
          internalSessions,
          eventStart,
          control: control || mode === 'ordinary-popup',
        })
      : String(mode).startsWith('callback') || mode === 'ordinary-authorize'
        ? await callbackTab({
            reader,
            client,
            idp: cross,
            ordinary,
            mode,
            tag,
            notes,
            budget,
            discovery,
            internalSessions,
            eventStart,
            control: control || mode === 'ordinary-authorize',
          })
        : { incomplete: `unknown signInHold mode ${mode}` };

  for (const id of [built.openerId, built.targetId].filter(Boolean))
    await outcome(reader.send('Target.closeTarget', { targetId: id }));
  return built;
}

export const SIGN_IN_HOLD_CALLBACK = CALLBACK;
export const SIGN_IN_HOLD_BODY = BODY;
export const SIGN_IN_HOLD_MARK = MARK_PREFIX;
